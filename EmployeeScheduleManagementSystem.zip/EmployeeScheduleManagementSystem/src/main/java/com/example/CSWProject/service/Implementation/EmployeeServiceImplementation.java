package com.example.CSWProject.service.Implementation;

import com.example.CSWProject.model.dto.request.CreateEmployeeRequest;
import com.example.CSWProject.model.dto.response.EmployeeResponse;
import com.example.CSWProject.model.entity.Employee;
import com.example.CSWProject.repository.EmployeeRepository;
import com.example.CSWProject.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImplementation implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Boolean createEmployee(List<CreateEmployeeRequest> createEmployeeRequests) {
        try{
            List<Employee> employees = new ArrayList<>();
            createEmployeeRequests.forEach(createEmployeeRequest -> {
                Employee employee = Employee.builder()
                        .email(createEmployeeRequest.getEmail())
                        .name(createEmployeeRequest.getName())
                        .build();
                employees.add(employee);
            });

            for(int i=0; i<employees.size(); i++){
                employeeRepository.save(employees.get(i));
            }
            return Boolean.TRUE;
        } catch (Exception e){
            return Boolean.FALSE;
        }
    }

    @Override
    public EmployeeResponse findEmployeeById(Long employeeId) {
        Optional<Employee> employee = employeeRepository.findById(employeeId);
        if(!employee.isPresent()){
            return null;
        }
        EmployeeResponse employeeResponse = EmployeeResponse.builder()
                .email(employee.get().getEmail())
                .name(employee.get().getName())
                .build();
        return employeeResponse;
    }

}
