package com.example.CSWProject.model.dto.request;

import com.example.CSWProject.model.enums.Frequency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateScheduleRequest {
    private Long scheduleId;
    private Date startDate;
    private Date endDate;
    private Time time;
    private int duration;
    private boolean repeat;
    private List<Frequency> frequencies;
}
