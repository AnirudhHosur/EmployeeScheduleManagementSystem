package com.example.CSWProject.service;

import com.example.CSWProject.model.dto.request.CreateEmployeeRequest;
import com.example.CSWProject.model.dto.response.EmployeeResponse;

import java.util.List;

public interface EmployeeService {
    Boolean createEmployee(List<CreateEmployeeRequest> createEmployeeRequests);

    EmployeeResponse findEmployeeById(Long employeeId);
}
