package com.example.CSWProject.controller;

import com.example.CSWProject.model.dto.request.CreateScheduleRequest;
import com.example.CSWProject.model.dto.request.UpdateScheduleRequest;
import com.example.CSWProject.model.dto.response.ScheduleResponse;
import com.example.CSWProject.repository.ScheduleRepository;
import com.example.CSWProject.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/schedule")
public class ScheduleController {

    @Autowired
    ScheduleService scheduleService;

    @PostMapping(value = "/createSchedule")
    Boolean saveSchedule(@RequestBody List<CreateScheduleRequest> createScheduleRequests) {
        return scheduleService.createSchedule(createScheduleRequests);
    }

    @PutMapping(value = "/updateSchedule")
    Boolean updateSchedule(@RequestBody UpdateScheduleRequest updateScheduleRequest) {
        return scheduleService.updateSchedule(updateScheduleRequest);
    }

    @GetMapping(value = "/getScheduleByEmpId/{employeeId}")
    ScheduleResponse getScheduleByEmpId(@RequestParam Long employeeId) {
        return scheduleService.listScheduleById(employeeId);
    }

    @DeleteMapping(value = "/deleteScheduleByScheduleId")
    Boolean delete(@RequestParam Long scheduleId) {
        return scheduleService.deleteSchedule(scheduleId);
    }
}
