package com.example.CSWProject.controller;

import com.example.CSWProject.model.dto.request.CreateEmployeeRequest;
import com.example.CSWProject.model.dto.response.EmployeeResponse;
import com.example.CSWProject.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping
    Boolean saveEmployeeDetails(@RequestBody List<CreateEmployeeRequest> createEmployeeRequests){
        return employeeService.createEmployee(createEmployeeRequests);
    }

    @GetMapping
    EmployeeResponse getEmployeeById(@RequestParam Long employeeId){
        return employeeService.findEmployeeById(employeeId);
    }
}
