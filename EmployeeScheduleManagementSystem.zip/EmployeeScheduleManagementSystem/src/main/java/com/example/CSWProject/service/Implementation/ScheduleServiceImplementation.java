package com.example.CSWProject.service.Implementation;

import com.example.CSWProject.model.dto.request.CreateScheduleRequest;
import com.example.CSWProject.model.dto.request.UpdateScheduleRequest;
import com.example.CSWProject.model.dto.response.ScheduleResponse;
import com.example.CSWProject.model.entity.Schedule;
import com.example.CSWProject.repository.ScheduleRepository;
import com.example.CSWProject.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ScheduleServiceImplementation implements ScheduleService {

    @Autowired
    private ScheduleRepository scheduleRepository;

    @Override
    public Boolean createSchedule(List<CreateScheduleRequest> createScheduleRequests) {
        try {
            List<Schedule> schedules = new ArrayList<>();
            createScheduleRequests.forEach(createScheduleRequest -> {
                Schedule schedule = Schedule.builder()
                        .scheduleId(createScheduleRequest.getEmployeeId())
                        .startDate(createScheduleRequest.getStartDate())
                        .endDate(createScheduleRequest.getEndDate())
                        .time(createScheduleRequest.getTime())
                        .duration(createScheduleRequest.getDuration())
                        .repeat(createScheduleRequest.isRepeat())
                        .frequencies(createScheduleRequest.getFrequencies())
                        .build();
                schedules.add(schedule);
            });
            for (int i = 0; i < schedules.size(); i++) {
                scheduleRepository.save(schedules.get(i));
            }
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    @Override
    public ScheduleResponse listScheduleById(Long employeeId) {
        Optional<Schedule> schedules = scheduleRepository.findById(employeeId);
        if(!schedules.isPresent()){
            return null;
        }
        ScheduleResponse scheduleResponse = ScheduleResponse.builder()
                .startDate(schedules.get().getStartDate())
                .endDate(schedules.get().getEndDate())
                .time(schedules.get().getTime())
                .duration(schedules.get().getDuration())
                .repeat(schedules.get().isRepeat())
                .frequencies(schedules.get().getFrequencies())
                .build();
        return scheduleResponse;

    }


    @Override
    public Boolean updateSchedule(UpdateScheduleRequest updateScheduleRequest) {
        try {
            Optional<Schedule> schedule = scheduleRepository.findById(updateScheduleRequest.getScheduleId());
            if(!schedule.isPresent()){
                return null;
            }
            schedule.get().setStartDate(updateScheduleRequest.getStartDate());
            schedule.get().setEndDate(updateScheduleRequest.getEndDate());
            schedule.get().setTime(updateScheduleRequest.getTime());
            schedule.get().setDuration(updateScheduleRequest.getDuration());
            schedule.get().setRepeat(updateScheduleRequest.isRepeat());
            schedule.get().setFrequencies(updateScheduleRequest.getFrequencies());
            scheduleRepository.save(schedule.get());
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    @Override
    public Boolean deleteSchedule(Long scheduleId) {
        try{
            Optional<Schedule> schedule = scheduleRepository.findById(scheduleId);
            scheduleRepository.delete(schedule.get());
            return Boolean.TRUE;
        } catch (Exception e){
            return Boolean.FALSE;
        }
    }

}
