package com.example.CSWProject.model.entity;

import com.example.CSWProject.model.enums.Frequency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static javax.persistence.EnumType.STRING;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "schedule")
public class Schedule {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long scheduleId;
    private Date startDate;
    private Date endDate;
    private Time time;
    private int duration;
    boolean repeat;
    @Enumerated(STRING)
    @ElementCollection
    @CollectionTable(name = "schedule_frequencies",
            joinColumns = @JoinColumn(name = "scheduleId"))
    @Column(name = "frequency")
    private List<Frequency> frequencies;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "employeeId", nullable = false)
    private Employee employee;
}
