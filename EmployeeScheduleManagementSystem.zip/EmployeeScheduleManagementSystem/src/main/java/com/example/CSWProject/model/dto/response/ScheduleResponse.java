package com.example.CSWProject.model.dto.response;

import com.example.CSWProject.model.enums.Frequency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.sql.Time;
import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleResponse {
    private Long employeeId;
    private Date startDate;
    private Date endDate;
    private Time time;
    private int duration;
    boolean repeat;
    private List<Frequency> frequencies;
}
