package com.example.CSWProject.service;

import com.example.CSWProject.model.dto.request.CreateScheduleRequest;
import com.example.CSWProject.model.dto.request.UpdateScheduleRequest;
import com.example.CSWProject.model.dto.response.ScheduleResponse;

import java.util.List;


public interface ScheduleService {
    Boolean createSchedule(List<CreateScheduleRequest> createScheduleRequests);

    ScheduleResponse listScheduleById(Long employeeId);

    Boolean updateSchedule(UpdateScheduleRequest updateScheduleRequest);

    Boolean deleteSchedule(Long scheduleId);
}
