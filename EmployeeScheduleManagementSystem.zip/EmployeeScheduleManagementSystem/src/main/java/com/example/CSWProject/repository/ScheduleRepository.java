package com.example.CSWProject.repository;

import com.example.CSWProject.model.dto.response.ScheduleResponse;
import com.example.CSWProject.model.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedule, Long> {
}
