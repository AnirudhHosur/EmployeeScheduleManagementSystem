package com.example.CSWProject.model.enums;

public enum Frequency {
    Weekdays("Weekdays"),
    Daily("Daily"),
    Weekly("Weekly"),
    Monthly("Monthly");

    Frequency(String title) {
        this.title = title;
    }

    private String title;

    public String getTitle() {
        return title;
    }
}
