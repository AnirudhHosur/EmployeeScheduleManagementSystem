package com.example.CSWProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CswProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
